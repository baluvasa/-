import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyFilterPipe } from './my-filter.pipe';
import { EventEmitterService } from './event-emitter.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { NewsComponent } from './news/news.component';
import { CompaniesComponent } from './companies/companies.component';
@NgModule({
  declarations: [
    AppComponent,
    MyFilterPipe,
    NewsComponent,
    CompaniesComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [EventEmitterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
